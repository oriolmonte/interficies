package com.oriol.classedos.dades

class DadesFake {
    companion object {
        val diesDeLaSetmana = listOf("Diumenge", "Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte")
    }

}