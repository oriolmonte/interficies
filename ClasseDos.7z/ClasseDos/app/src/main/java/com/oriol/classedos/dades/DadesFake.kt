package com.oriol.classedos.dades

class DadesFake {
    companion object {
        val diesDeLaSetmana = listOf("Dg", "Dl", "Dm", "Dx", "Dj", "Dv", "Ds")
    }

}